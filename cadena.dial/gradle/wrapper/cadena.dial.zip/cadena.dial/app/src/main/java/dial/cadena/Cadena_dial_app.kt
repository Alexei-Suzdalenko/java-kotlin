package dial.cadena
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.annotation.RequiresApi

class Cadena_dial_app : Application() {
    companion object{
        const val channel_id = "cadena-dial"
        const val name = "Cadena Dial Radio"
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(){
        super.onCreate()


           val serChannel = NotificationChannel(channel_id, name, NotificationManager.IMPORTANCE_DEFAULT)
           val manager = getSystemService(NotificationManager::class.java)
               manager?.createNotificationChannel(serChannel)

    }


}