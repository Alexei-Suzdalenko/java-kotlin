package dial.cadena
import android.app.Service
import android.content.Intent
import android.os.IBinder
class Service_cadena_dial: Service() {
    override fun onBind(intent: Intent?): IBinder? {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}