package cadena.dial.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import cadena.dial.R

class HomeFragment : Fragment() {

    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        val play: ImageView  = root.findViewById(R.id.play)
        val stop : ImageView = root.findViewById(R.id.stop)

        play.setOnClickListener {
            play.visibility = View.GONE
            stop.visibility = View.VISIBLE
        }

        stop.setOnClickListener {
            stop.visibility = View.GONE
            play.visibility = View.VISIBLE
        }
        return root
    }
}
